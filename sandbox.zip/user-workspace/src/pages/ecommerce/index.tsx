import React, { useState } from 'react'
import {
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Box,
  TextField,
  IconButton,
  Chip,
  Stack
} from '@mui/material'
import {
  Add as AddIcon,
  Store as StoreIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon
} from '@mui/icons-material'

interface Store {
  id: number
  name: string
  products: number
  revenue: string
  status: 'active' | 'inactive'
}

import Head from 'next/head'

export default function Ecommerce() {
  const [stores, setStores] = useState<Store[]>([
    { 
      id: 1, 
      name: 'Boutique Mode', 
      products: 150, 
      revenue: '15000€',
      status: 'active'
    },
    { 
      id: 2, 
      name: 'Boutique Tech', 
      products: 75, 
      revenue: '8000€',
      status: 'active'
    },
    { 
      id: 3, 
      name: 'Boutique Déco', 
      products: 200, 
      revenue: '12000€',
      status: 'inactive'
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <Box sx={{ maxWidth: 1200, mx: 'auto', p: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Gestion E-commerce
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          color="primary"
        >
          Nouvelle Boutique
        </Button>
      </Box>
      
      <Box sx={{ mb: 4 }}>
        <TextField
          label="Rechercher une boutique"
          variant="outlined"
          fullWidth
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ mb: 2 }}
        />
      </Box>

      <Grid container spacing={3}>
        {filteredStores.map((store) => (
          <Grid item xs={12} sm={6} md={4} key={store.id}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <StoreIcon sx={{ mr: 1, color: 'primary.main' }} />
                  <Typography variant="h6">{store.name}</Typography>
                </Box>
                <Stack spacing={1}>
                  <Typography color="text.secondary">
                    Produits: {store.products}
                  </Typography>
                  <Typography color="text.secondary">
                    Revenu: {store.revenue}
                  </Typography>
                  <Chip 
                    label={store.status === 'active' ? 'Actif' : 'Inactif'}
                    color={store.status === 'active' ? 'success' : 'default'}
                    size="small"
                  />
                </Stack>
              </CardContent>
              <CardActions>
                <IconButton size="small" color="primary" title="Voir">
                  <ViewIcon />
                </IconButton>
                <IconButton size="small" color="primary" title="Modifier">
                  <EditIcon />
                </IconButton>
                <IconButton size="small" color="error" title="Supprimer">
                  <DeleteIcon />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  )
}
