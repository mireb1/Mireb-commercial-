
























import React, { useState, useEffect } from 'react'
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition'
import {
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Box,
  TextField,
  IconButton,
  Chip,
  Stack,
  Avatar
} from '@mui/material'
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  ChatBubble as ChatIcon
} from '@mui/icons-material'

interface Customer {
  id: number
  name: string
  email: string
  phone: string
  status: 'active' | 'inactive' | 'lead'
  lastContact: string
  totalPurchases: string
}

import Head from 'next/head'

/**
 * CRM component serves as the management interface for customer data.
 * It allows users to view, search, and manage customer information.
 */
export default function CRM() {
  /**
   * customers state holds the list of customer objects.
   * Each customer object contains details such as id, name, email, phone, status, last contact date, and total purchases.
   */
  const [customers, setCustomers] = useState<Customer[]>([
    {
      id: 1,
      name: 'Jean Dupont',
      email: 'jean.dupont@email.com',
      phone: '+33 6 12 34 56 78',
      status: 'active',
      lastContact: '2024-01-05',
      totalPurchases: '2500€'
    },
    {
      id: 2,
      name: 'Marie Martin',
      email: 'marie.martin@email.com',
      phone: '+33 6 23 45 67 89',
      status: 'lead',
      lastContact: '2024-01-08',
      totalPurchases: '0€'
    },
    {
      id: 3,
      name: 'Pierre Bernard',
      email: 'pierre.bernard@email.com',
      phone: '+33 6 34 56 78 90',
      status: 'inactive',
      lastContact: '2023-12-15',
      totalPurchases: '1200€'
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'success'
      case 'lead':
        return 'warning'
      case 'inactive':
        return 'error'
      default:
        return 'default'
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Client Actif'
      case 'lead':
        return 'Prospect'
      case 'inactive':
        return 'Inactif'
      default:
        return status
    }
  }

  return (
    <Box sx={{ maxWidth: 1200, mx: 'auto', p: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Gestion CRM
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          color="primary"
        >
          Nouveau Client
        </Button>
      </Box>
      
      <Box sx={{ mb: 4 }}>
        <TextField
          label="Rechercher un client"
          variant="outlined"
          fullWidth
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ mb: 2 }}
        />
      </Box>

      <Grid container spacing={3}>
        {filteredCustomers.map((customer) => (
          <Grid item xs={12} sm={6} md={4} key={customer.id}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar sx={{ mr: 2, bgcolor: 'primary.main' }}>
                    {customer.name.charAt(0)}
                  </Avatar>
                  <Box>
                    <Typography variant="h6">{customer.name}</Typography>
                    <Chip 
                      label={getStatusLabel(customer.status)}
                      color={getStatusColor(customer.status)}
                      size="small"
                      sx={{ mt: 0.5 }}
                    />
                  </Box>
                </Box>
                <Stack spacing={1}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <EmailIcon sx={{ mr: 1, fontSize: 'small', color: 'text.secondary' }} />
                    <Typography variant="body2">{customer.email}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <PhoneIcon sx={{ mr: 1, fontSize: 'small', color: 'text.secondary' }} />
                    <Typography variant="body2">{customer.phone}</Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Dernier contact: {new Date(customer.lastContact).toLocaleDateString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total achats: {customer.totalPurchases}
                  </Typography>
                </Stack>
              </CardContent>
              <CardActions>
                <IconButton size="small" color="primary" title="Envoyer un email">
                  <EmailIcon />
                </IconButton>
                <IconButton size="small" color="primary" title="Appeler">
                  <PhoneIcon />
                </IconButton>
                <IconButton size="small" color="primary" title="Chat">
                  <ChatIcon />
                </IconButton>
                <IconButton size="small" color="primary" title="Modifier">
                  <EditIcon />
                </IconButton>
                <IconButton size="small" color="error" title="Supprimer">
                  <DeleteIcon />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  )
}
