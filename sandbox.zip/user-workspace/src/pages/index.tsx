import React from 'react'
import { Typography, Grid, Paper, Box, Button } from '@mui/material'
import {
  Store as StoreIcon,
  People as PeopleIcon,
  Business as BusinessIcon,
  Group as GroupIcon
} from '@mui/icons-material'
import Link from 'next/link'

const DashboardCard = ({ title, description, icon, link }: {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
}) => (
  <Paper sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
      <Box sx={{ mr: 2, color: 'primary.main' }}>{icon}</Box>
      <Typography variant="h6">{title}</Typography>
    </Box>
    <Typography sx={{ mb: 2 }} color="text.secondary">
      {description}
    </Typography>
    <Box sx={{ mt: 'auto' }}>
      <Link href={link} passHref>
        <Button variant="contained">
          Accéder
        </Button>
      </Link>
    </Box>
  </Paper>
)

/**
 * Home component serves as the main entry point for the dashboard.
 * It displays various sections of the application, allowing users to navigate to different functionalities.
 */
export default function Home() {
  /**
   * dashboardItems array contains the details for each section of the dashboard.
   * Each item includes a title, description, icon, and link to the respective page.
   */
  const dashboardItems = [
    {
      title: 'E-commerce',
      description: 'Gérez vos boutiques en ligne, produits et commandes',
      icon: <StoreIcon fontSize="large" />,
      link: '/ecommerce'
    },
    {
      title: 'CRM',
      description: 'Gérez vos clients et suivez vos interactions',
      icon: <PeopleIcon fontSize="large" />,
      link: '/crm'
    },
    {
      title: 'Immobilier',
      description: 'Gérez vos biens immobiliers et locations',
      icon: <BusinessIcon fontSize="large" />,
      link: '/real-estate'
    },
    {
      title: 'Associations',
      description: 'Gérez vos membres et événements associatifs',
      icon: <GroupIcon fontSize="large" />,
      link: '/associations'
    }
  ]

  return (
    <Box sx={{ maxWidth: 1200, mx: 'auto', p: 2 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4 }}>
        Tableau de Bord
      </Typography>
      <Grid container spacing={3}>
        {dashboardItems.map((item) => (
          <Grid item xs={12} sm={6} md={3} key={item.title}>
            <DashboardCard {...item} />
          </Grid>
        ))}
      </Grid>
    </Box>
  )
}
